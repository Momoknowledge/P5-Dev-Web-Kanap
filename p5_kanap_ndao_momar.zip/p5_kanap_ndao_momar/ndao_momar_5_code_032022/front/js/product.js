
function getItemID() {
    return new URL(window.location.href).searchParams.get("id");
}

/**
 * Affiche l'élément d'un produit
 * @param item object reçu par l'api
 */
function displayItem(item) {
    document.querySelector(".item__img").append(ce('img',{
        src: item.imageUrl,
        alt: item.altTxt
    }));

    document.getElementById('title').textContent = item.name;
    document.getElementById('price').textContent = item.price;
    document.getElementById('description').textContent = item.description;

    const frag = new DocumentFragment();
    for (const color of item.colors) {
        frag.append(ce('option', {value: color}, color));
    }

    document.querySelector("#colors").append(frag);
}

/**
 * ajouter les elements dans le panier
 * @param item
 */
function addToCartAction(item) {
    const colorPickedElm    = document.querySelector("#colors");
    const quantityPickedElm = document.querySelector("#quantity");
    const btn_envoyerPanier = document.querySelector("#addToCart");

    btn_envoyerPanier.addEventListener("click", () => {
        const quantityPicked = clamp(Number.parseInt(quantityPickedElm.value),1,100),
              colorPicked = colorPickedElm.value;

        if (!Number.isFinite(quantityPicked) || !colorPicked) return;

        const cart = loadCart();
        const cartItem = cart.find(el => el._id === item._id && el.color === colorPicked);

        if (cartItem) cartItem.quantity = clamp(quantityPicked + cartItem.quantity,1,100);
        else cart.push({
            _id: item._id,
            color: colorPicked,
            quantity: quantityPicked,
        });

        saveCart(cart);

        if (window.confirm(
            `Votre commande de ${quantityPicked} ${item.name} ${colorPicked}`
            +` est ajoutée au panier\nPour consulter votre panier, cliquez sur OK`
        )) {
            window.location.href = "cart.html";
        }
    });
}

(async () => {
    try {
        const item = await fetchItem(getItemID());
        displayItem(item);
        addToCartAction(item);
    } catch (err) {
        console.error(err);
    }
})();
