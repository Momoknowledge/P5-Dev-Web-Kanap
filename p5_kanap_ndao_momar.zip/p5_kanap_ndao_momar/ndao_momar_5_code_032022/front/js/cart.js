/**
 * Enlève l'élément et la reference de la commande courante dans le panier.
 * @param products
 * @param cartData
 * @param cartElmRef
 * @param item
 * @returns {(function(*): void)|*}
 */
function removeCartItemAction(products, cartData, cartElmRef, item) {
    return e => {
        e.preventDefault();

        const idx = cartData.indexOf(item);
        if (idx < 0 || !confirm(`Voulez vous vraiment supprimer ${products[item._id].name} ?`)) return;

        // supprime 1 élément à l'index idx
        cartData.splice(idx, 1);

        saveCart(cartData);

        cartElmRef.current.remove();
        displayTotals(products, cartData);
    };
}

/**
 * Remplir quantité d'éléments dans le panier entre minimum 1 et 100 maximum
 * @param products
 * @param cartData
 * @param item
 * @returns {(function(*): void)|*}
 */
function updateCartItemQuantityAction(products, cartData, item) {
    return e => {
        const value = e.target.valueAsNumber; // Number.parseInt(e.target.value);
        if (!Number.isFinite(value)) return;

        if (value > 100) e.target.value = 100;
        else if (value < 1) e.target.value = 1;

        item.quantity = clamp(value, 1, 100);

        saveCart(cartData)
        displayTotals(products, cartData);
    };
}

/**
 * Crée un élément du panier
 * @param products
 * @param cartData
 * @param item
 * @returns {HTMLElement}
 */
function createCartItem(products, cartData, item) {
    const prodItem = products[item._id];
    const cartElmRef = {current: null};

    // noinspection JSUnusedGlobalSymbols
    return cartElmRef.current = ce("article", {className: "cart__item", "data-id": item._id, "data-color": item.color}, [
        ce("div", {className: "cart__item__img"}, ce("img", {src: prodItem.imageUrl, alt: prodItem.altTxt})),
        ce("div", {className: "cart__item__content"}, [
            ce("div", {className: "cart__item__content__description"}, [
                ce("h2", null, prodItem.name),
                ce("p", null, item.color),
                ce("p", null, prodItem.price + " €"),
            ]),
            ce("div", {className: "cart__item__content__settings"}, [
                ce("div", {className: "cart__item__content__settings__quantity"}, [
                    ce("p", null, "Qté : "),
                    ce("input", {
                        className: "itemQuantity",
                        name: "itemQuantity",
                        type: "number",
                        min: "1", max: "100",
                        value: item.quantity.toString(),
                        onChange: updateCartItemQuantityAction(products, cartData, item),
                    }),
                ]),
                ce("div", {className: "cart__item__content__settings__delete"},
                    ce("p", {
                        className: "deleteItem",
                        onClick: removeCartItemAction(products, cartData, cartElmRef, item),
                    }, "Supprimer"),
                ),
            ]),
        ]),
    ]);
}

/**
 *Affichage du produit et les données du panier
 * @param products
 * @param cartData
 */
function displayCart(products, cartData) {
    displayTotals(products, cartData);

    if (!cartData.length) {
        const positionEmptyCart = document.querySelector("#cart__items");
        positionEmptyCart.innerHTML = "<p>Votre panier est vide</p>";
        return;
    }

    // stockage en mémoire du document fragment pour éviter un reflow
    const fragment = new DocumentFragment();
    for (const item of cartData) {
        fragment.appendChild(createCartItem(products, cartData, item));
    }

    const cont = document.querySelector("#cart__items");
    cont.innerHTML = '';
    cont.appendChild(fragment);
}

/**
 * calcule la quantité et le prix des éléments du panier
 * @param products
 * @param cartData
 */
function displayTotals(products, cartData) {
    let totalPrice = 0,
        totalQuantity = 0;

    for (const item of cartData) {
        totalPrice    += products[item._id].price * item.quantity;
        totalQuantity += item.quantity;
    }

    document.getElementById('totalPrice').textContent = totalPrice.toString();
    document.getElementById('totalQuantity').textContent = totalQuantity.toString();
}

/**
 * Validation du champ de contact
 * @param elm
 * @param re
 * @param errorMessage
 * @returns {(function(*): (boolean))|*}
 */
function validateContactField(elm, re, errorMessage = undefined) {
    const errorElm = elm.nextElementSibling;
    return value => {
        value = value.trim(); //efface le whitespace de debut et de fin string

        if (value.length && re.test(value)) {
            errorElm.textContent = '';
            return true;
        }

        errorElm.textContent = !value.length && errorMessage ? 'Veuillez renseigner ce champ.' : errorMessage;
        return false;
    }
}

/**
 * Prepare les données de contact de validation
 * @param fieldsValidation
 * @param elm
 * @param re
 * @param errorMessage
 */
function initContactFieldValidation(fieldsValidation, elm, re, errorMessage) {
    const validate = validateContactField(elm, re, errorMessage);
    fieldsValidation[elm.name] = validate;
    elm.addEventListener('change', () => validate(elm.value));
}

/**
 * initialisation des données de contact de validation dans le champ du formulaire
 * @param form
 */
function initContactFormFields(form) {
    const fieldsValidation = {};
    const nameTest = /^[a-zA-Z\u00C0-\u00FF -]{2,50}$/;

    initContactFieldValidation(fieldsValidation, form.firstName, nameTest, 'Prénom invalide');
    initContactFieldValidation(fieldsValidation, form.lastName, nameTest, 'Nom Invalide');
    initContactFieldValidation(fieldsValidation, form.email, /^[\w.-]+@[\w.-]+\.[a-z]{2,6}$/, 'Email Invalide');
    initContactFieldValidation(fieldsValidation, form.address, /^.+$/, 'Adresse Invalide');
    initContactFieldValidation(fieldsValidation, form.city, /^[a-zA-Z- ]{2,}$/, 'Ville Invalide');

    return fieldsValidation;
}

/**
 * regarde si tous les champs du formulaire sont valides
 * @param fieldsValidation
 * @param contact
 * @returns {boolean}
 */
function checkAllContactFormFields(fieldsValidation, contact) {
    let test = true;
    for (const key in contact) {
        if (!fieldsValidation[key] || !fieldsValidation[key](contact[key])) test = false;
    }
    return test;
}

/**
 *envoie du formulaire
 * @param form
 * @param fieldsValidation
 * @param cartData
 */
function initialisationEnvoiFormulaire(form, fieldsValidation, cartData) {
    form.addEventListener('submit', e => {
        e.preventDefault();

        if (!cartData.length) {
            return alert("Le panier est vide !");
        }

        const contact = Object.fromEntries(new FormData(form).entries()); // recuperation des données saisies dans le formulaire
        if (!checkAllContactFormFields(fieldsValidation, contact)) {
            return alert("Le formulaire est mal rempli !");
        }

        saveOrder({
            contact: contact,
            products: cartData.map(x => x._id), // Récupère la reference id du produit dans les données du panier
        });

        removeCart();
        document.location.href = "confirmation.html" //rédige vers la page de confirmation html
    });
}

/**
 *initialise le formulaire de contact
 * @param cartData
 */
function initContactForm(cartData) {
    const form = document.querySelector(".cart__order__form");
    const fieldsValidation = initContactFormFields(form);
    initialisationEnvoiFormulaire(form, fieldsValidation, cartData);
}

/**
 * trier les elements du panier par IDs
 * @param cart
 */
function sortItemsByIDs(cart) {
    cart.sort((a, b) => a._id <= b._id ? -1 : 1);
}

(async () => {
    const products = await fetchAllProductsParsed();
    const cart = loadCart();

    sortItemsByIDs(cart);

    initContactForm(cart);

    displayCart(products, cart);
})();