(() => {

    const order = loadOrder();
    if (!order) return;
    removeOrder();

    postOrder(order).then(({orderId}) => {
        document.getElementById("orderId").textContent = orderId;
    }).catch(console.error);

})();

