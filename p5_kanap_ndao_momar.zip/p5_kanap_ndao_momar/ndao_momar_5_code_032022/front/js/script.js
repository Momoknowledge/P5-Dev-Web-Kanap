/**
 * Create Element -> create html element
 *
 *
 * @param item
 * @returns {*}
 */
function createItem(item) {
    return ce("a", {href: `product.html?id=${item._id}`},
        ce ('article',{},[
            ce('img',{src: item.imageUrl, alt: item.altTxt}),
            ce('h3',{className: "productName"},item.name),
            ce('p',{className: "productDescription"},item.description),
        ])
    );
}

(async () => {
    try {
        const items = await fetchAllProducts();

        const frag = new DocumentFragment();
        for (const item of items) {
            frag.appendChild(createItem(item));
        }

        document.querySelector(".items").appendChild(frag);
    } catch (err) {
        console.error(err);
    }
})();