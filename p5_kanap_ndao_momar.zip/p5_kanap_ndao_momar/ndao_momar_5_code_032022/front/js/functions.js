//Initialisation du local storage
/**
 * @typedef {Object} Produit
 * @property {string} _id
 * @property {string} imageUrl
 * @property {string} altTxt
 * @property {string} name
 * @property {string} color
 * @property {number} price
 * @property {number} quantity
 */

/**
 * @typedef {Object} CartItem
 * @property {string} _id
 * @property {string} color
 * @property {number} quantity
 */


const LOCAL_STORAGE_KEY_CART = "current-cart";
const LOCAL_STORAGE_KEY_ORDER = "pending-order";

/**
 * Create Element -> create html element
 * @param tag html tag name
 * @param attributes object {attributName: attributeValue}
 * @param children array of [or single] child node
 * @returns {*} created element
 */
function ce(tag, attributes, children) {
    const elm = document.createElement(tag);

    if (attributes) for (const attrName in attributes) {
        if (/^on[A-Z]/.test(attrName)) elm.addEventListener(attrName.substring(2).toLowerCase(), attributes[attrName]);
        else elm.setAttribute(attrName === "className" ? "class" : attrName, attributes[attrName]);
    }

    if (children) {
        if (!Array.isArray(children)) children = [children];
        for (const child of children) elm.append(child);
    }

    return elm;
}

/**
 * renvoie une valeur entre un minimum et un maximum
 * @param v {number} valeur à clamper
 * @param min {number} valeur minimum
 * @param max {number} valeur maximum
 * @returns {number} valeur clampée
 */
function clamp(v, min, max) {
    return Math.min(max, Math.max(min, v));
}

/**
 * Charge le panier s'il n'existe pas crée un panier vide
 * @returns {CartItem[]}
 */
function loadCart() {
    return JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY_CART)) || [];
}

/**
 * Sauvegarde le panier dans le local storage
 * @param cartData {CartItem[]}
 */
function saveCart(cartData) {
    localStorage.setItem(LOCAL_STORAGE_KEY_CART, JSON.stringify(cartData));
}

/**
 * supprimer les paniers dans le local storage
 */
function removeCart() {
    localStorage.removeItem(LOCAL_STORAGE_KEY_CART);
}

/**
 * charger la commande dans le local storage
 * @returns {any|null}
 */
function loadOrder() {
    return JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY_ORDER)) || null;
}

/**
 * sauvegarder la commande dans le local storage
 * @param order
 */
function saveOrder(order) {
    localStorage.setItem(LOCAL_STORAGE_KEY_ORDER, JSON.stringify(order));
}

/**
 * Supprime la commande dans le local storage
 */
function removeOrder() {
    localStorage.removeItem(LOCAL_STORAGE_KEY_ORDER);
}

/**
 * recuperation de tous les produits dans l'Api
 * @returns {Promise<any>}
 */
async function fetchAllProducts() {
    const res = await fetch("http://localhost:3000/api/products");
    if (!res.ok) throw res.statusText;
    return await res.json();
}

/**
 *
 * @returns {Promise<{}>}
 */
async function fetchAllProductsParsed() {
    const prod = await fetchAllProducts();
    const p = {};
    for (const item of prod) {
        p[item._id] = item;
    }

    return p;
}

/**
 * recuperation l'id des éléments dans l'api
 * @param itemID
 * @returns {Promise<any>}
 */
async function fetchItem(itemID) {
    const res = await fetch("http://localhost:3000/api/products/" + itemID);
    if (!res.ok) throw res.statusText;

    return await res.json();
}

/**
 * Envoie, des données products apres modification
 * @param order
 * @returns {Promise<any>}
 */
async function postOrder(order) {
    const res = await fetch("http://localhost:3000/api/products/order", {
        method: 'POST',
        body: JSON.stringify(order),
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json"
        },
    });
    if (!res.ok) throw res.statusText;
    return await res.json();
}